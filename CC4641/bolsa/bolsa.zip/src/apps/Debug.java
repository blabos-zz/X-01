package bolsa;


class Debug {
    static void print() {
        System.err.println();
    }
    
    static void print(String msg) {
        System.err.println(msg);
    }
};
